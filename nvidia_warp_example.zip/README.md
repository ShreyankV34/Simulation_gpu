
# NVIDIA Warp Example

This project demonstrates the use of NVIDIA Warp for high-performance GPU simulations. 
We will compare the performance of a simple array summation function with and without JIT compilation and profile the execution time.

## Setup

1. Create a virtual environment and activate it:
    ```sh
    python -m venv venv
    source venv/bin/activate  # On Windows, use `venv\Scripts\activate`
    ```

2. Install the required packages:
    ```sh
    pip install warp-lang numba
    ```

## Running the Code

Run the main script to see the results:
```sh
python src/main.py
```

## Files

- `src/main.py`: Contains the main code for comparing JIT and non-JIT execution using NVIDIA Warp.
