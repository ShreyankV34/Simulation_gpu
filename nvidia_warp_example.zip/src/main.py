
import cProfile
import pstats
import time
from numba import jit
import warp as wp
import numpy as np

def sum_arrays_no_jit(a, b):
    result = []
    for i in range(len(a)):
        result.append(a[i] + b[i])
    return result

@jit(nopython=True)
def sum_arrays_jit(a, b):
    result = []
    for i in range(len(a)):
        result.append(a[i] + b[i])
    return result

@wp.kernel
def sum_arrays_warp(a: wp.array(dtype=float), b: wp.array(dtype=float), c: wp.array(dtype=float)):
    i = wp.tid()
    c[i] = a[i] + b[i]

def main():
    num_elements = 10000000
    a = np.random.rand(num_elements).astype(np.float32)
    b = np.random.rand(num_elements).astype(np.float32)

    # Timing without JIT
    start_time = time.time()
    result = sum_arrays_no_jit(a, b)
    end_time = time.time()
    print(f"Time without JIT: {end_time - start_time} seconds")

    # Warm-up run to compile the JIT function
    sum_arrays_jit(a, b)

    # Timing with JIT
    start_time = time.time()
    result = sum_arrays_jit(a, b)
    end_time = time.time()
    print(f"Time with JIT: {end_time - start_time} seconds")

    # Allocate arrays on the GPU using Warp
    wp_a = wp.array(a)
    wp_b = wp.array(b)
    wp_c = wp.zeros_like(wp_a)

    # Timing with Warp
    start_time = time.time()
    wp.launch(kernel=sum_arrays_warp, dim=num_elements, inputs=[wp_a, wp_b, wp_c])
    end_time = time.time()
    print(f"Time with Warp: {end_time - start_time} seconds")

if __name__ == "__main__":
    cProfile.run('main()', 'profile_results')

    # Print the profiling results
    p = pstats.Stats('profile_results')
    p.sort_stats('cumulative').print_stats(10)
